#include <stdio.h>
#include <stdlib.h>
#include "ctty.h"

int main(int argc, char *argv[]) {

    clear();
    mvoutstr(5, 12, "I like Linux\n");

	return 0;
}
